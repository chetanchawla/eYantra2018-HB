#!/usr/bin/env python
import rospy
import roslib


from geometry_msgs.msg import PoseArray
from aruco_msgs.msg import MarkerArray
rospy.Subscriber('/vrep/waypoints',PoseArray, callBack2)	# Subscribing to topic
def callBack2(msg):
	print(msg)